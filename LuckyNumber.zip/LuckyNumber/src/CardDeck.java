import java.util.ArrayList;


public class CardDeck {

		private ArrayList<Card> deck;
	
	public CardDeck(){
		deck=new ArrayList<Card>();
		create("diamond");
		create("spade");
		create("heart");
		create("club");
		
	}
	public void create(String suit){
		for(int i=1;i<=13;i++){
			Card card=new Card(suit,i);
			deck.add(card);	
		}
	}
	public ArrayList<Card> getDeck(){
		return deck;
	}
	//replenishes deck
	public void shuffle(ArrayList<Card> discardPile){
		this.deck=discardPile;
		//could clear on the other side
		discardPile.clear();
	}
	public ArrayList<Card> draw(int amount,ArrayList<Card> discardPile){
		
		//automated shuffle if all cards are used
		ArrayList<Card> list=new ArrayList<Card>();
			for(int i = 0;i<amount;i++){
				if(deck.isEmpty()){
					shuffle(discardPile);
				}
				int ran=(int)(Math.random() * deck.size());
				Card card=deck.get(ran);
				deck.remove(ran);
				list.add(card);
			}
		
		return list;
	}
	public int deckCount(){
		return deck.size();
	}
	
	
}
