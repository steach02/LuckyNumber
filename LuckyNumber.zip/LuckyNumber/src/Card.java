
public class Card {

	private int cardValue;
	private int drinkValue;
	private String cardSuit;
	
	public Card(String suit, int value){
		this.cardValue=value;
		this.cardSuit=suit;
		this.drinkValue=drinkValue(value);
	}
	public int getCardValue(){
		return cardValue;
	}
	public String getCardSuit(){
		return cardSuit; 
	}	
	public void print(){
		System.out.print(cardValue+" of "+cardSuit+", ");
	}
	public int drinkValue(int value){
		if(value<=10){
			return value;
		}else if(value>10){
			return 10;
		}else{
			return 0;
		}
	}
	public int getDrinkValue(){
		return drinkValue;
	}
}
