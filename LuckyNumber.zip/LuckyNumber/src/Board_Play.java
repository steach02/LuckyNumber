import java.util.ArrayList;
import java.util.Scanner;


public class Board_Play {

	private static int numOfPlayers;	
	private static Player nextPlayer;
	private static int streak=0;
	private static Card topCard;
	private static CardDeck deck;
	private static ArrayList<Player> playerList;
	private static ArrayList<Card> discardPile;
	private static Scanner in = new Scanner(System.in);

	private static Player currentPlayer=null;
	private static int multiplier=1;


	private static boolean run() {
		//adjust the player as needed
		Player previousePlayer=currentPlayer;
		currentPlayer=nextPlayer;
		Card previouseCard = topCard;
		
		//let the player play a card we put it after the null check so 
		topCard = currentPlayer.playCard();
		//is the card a seven 
		if(topCard.getCardValue()==7){
			streak++;
			if(streak==3){
				System.out.println("Yay you win game over!!");
				end();
			}
		}else if(streak>0){
			streak=0;
		}
		if(previouseCard==null||previousePlayer==null){
			if(isLucky(topCard)){
				multiplier++;
			}

			setNext(currentPlayer);
			return false;
			
		}
		
		//played lucky
		if(isLucky(topCard)){
				luckyLoop(currentPlayer,previousePlayer,previouseCard,topCard);
		//did not play a lucky
		}else{
				nonLuckyLoop(previouseCard,topCard);
		}

return true;

	}

	private static void luckyLoop(Player currentPlayer,Player previousePlayer, Card previouseCard,Card top) {
		//the previouse card is a lucky played by its owner clears multiplier and gets treated like a regular card 

		if(previousePlayer.isLucky(previouseCard)&&!isLucky(top)){
		multiplier=1;
		nonLuckyLoop(previouseCard,top);
		}else{
			//played your own lucky
			if(currentPlayer.isLucky(top)){
				//reset multiplier,setNext
				multiplier=1;
				setNext(currentPlayer);
			//played someone elseslucky
			}else{
				//send to whomever the lucky belongs to add one to multiplier
				multiplier++;
				setNext(top,true);
			}
		}
	}

	private static void nonLuckyLoop(Card previouse,Card top) {		
		if(isLucky(previouse)){
			System.out.println("lucky vs unlucky");

			//lose allocate drinks, clear multiplier, set Next Player.
			allocateDrinks(currentPlayer,multiplier,top);
			setNext(currentPlayer);
			multiplier=1;
		}
		if(top.getCardValue()>=previouse.getCardValue()){
			//win set next player
			//check if the card is a double of the previouse
			if(previouse.getCardValue()==top.getCardValue()){
				skip(currentPlayer);
			}else{
			setNext(currentPlayer);
			}
		}else{
			//lose allocate drinks set next player
			allocateDrinks(currentPlayer,multiplier,top);
			setNext(currentPlayer);
		}
	}

	private static void allocateDrinks(Player currentPlayer2, int multiplier2,
			Card topCard2) {
		System.out.println(currentPlayer.getName()+" has "+(topCard.getDrinkValue()*multiplier)+" drinks");
		multiplier=1;
		currentPlayer.setDrinks(topCard.getCardValue());
	}

	private static void initialize(Scanner in) {
		deck = new CardDeck();
		discardPile = new ArrayList<Card>();

		//fill in the players
		System.out.println("How many players 3-6?");
		numOfPlayers = in.nextInt();
		playerList = new ArrayList<Player>();
//error handleing
		for(int i=0;i<numOfPlayers;i++){
			System.out.println("Who is player "+(i+1)+"?");
			String name = in.next();
			System.out.println("What is player "+(i+1)+"'s Lucky Number 1-13?");
			int lucky = in.nextInt();
			Player player = new Player(name,lucky,discardPile,deck,in);
			playerList.add(player);
		}

		//set the initial card to beat
		//card is removed from deck dont put top card into discard pile until there is a new top card
		//dont forget to move topcard to discardPile
		topCard = deck.draw(1, discardPile).get(0);
		//set the player who will start the game
		nextPlayer = playerList.get(0);
	}
	private static void displayInstructions() {
		System.out.println("alskdjfghkjwwadhfkjalsdfkjasdhfkjh.");
		System.out.println("Press any button then enter to continue.");
		in.next();
	}

	private static void setNext(Card top, boolean b) {
		
		//first find who the card belongs to then set them as the next player
		for(Player player:playerList){
			if(player.isLucky(top)){
				nextPlayer=player;
				break;
			}
		}

	}

	private static void setNext(Player currentPlayer) {
		if(playerList.indexOf(currentPlayer)==playerList.size()-1){
			nextPlayer=playerList.get(0);
		}else{
		nextPlayer=playerList.get(playerList.indexOf(currentPlayer)+1);
		}
	}

	private static void end() {
		System.exit(0);
	}

	private static boolean isLucky(Card card) {
		for(Player player:playerList){
			if(player.isLucky(card)){

				return true;
			}
		}
		return false;
	}

	private static void skip(Player currentPlayer2) {
		//the person skiped gets 1 drink
		//as long as moving ahead two players does not move the array out of bounds then set that player
		if(numOfPlayers>playerList.indexOf(currentPlayer)+2){
			System.out.println(playerList.get(playerList.indexOf(currentPlayer)+1)+" gets 1 drink");
			playerList.get(playerList.indexOf(currentPlayer)+2).setDrinks(1);
			nextPlayer=playerList.get(playerList.indexOf(currentPlayer)+2);
			
		}else{
			
			//if you are to close to the end of the list then turn the corner
			playerList.get((playerList.indexOf(currentPlayer)+1)%numOfPlayers);
			nextPlayer=playerList.get((playerList.indexOf(currentPlayer)+2)%numOfPlayers);
		}
	}
	public static void main(String args[]){
		displayInstructions();
		initialize(in);
		while(streak!=3){
			run();
		}

	}

}
