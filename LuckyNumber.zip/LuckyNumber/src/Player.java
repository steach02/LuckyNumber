import java.util.ArrayList;
import java.util.Scanner;


public class Player {
	private String name;
	private int lucky;
	private int drinks;
	private ArrayList<Card> hand;
	private ArrayList<Card> discardPile;
	private CardDeck deck;
	private Scanner in;
	public Player(String name,int lucky,ArrayList<Card> discardPile,CardDeck deck,Scanner in){
		this.name=name;
		this.lucky=lucky;
		this.discardPile=discardPile;
		this.deck=deck;
		this.in=in;
		draw(7);
	}

	public void draw(int i){
		hand=deck.draw(i, discardPile);
	}
	public Card playCard(){
		//automated draw
		System.out.println(name+"'s Hand: ");
		for(Card card:hand){
			card.print();
		}
		// we can use regex here but since we will build ui there is no need

		System.out.println("What would you like to play enter 1-13");
		int num=in.nextInt();
		//check if card is in hand
		boolean b=true;
		while(b){

			for(Card card:hand){
				//if it is in the hand return it
				if(num==card.getCardValue()){
					b=false;
					hand.remove(card);
					if(hand.size()==0){
						deck.draw(7, discardPile);

					}
					return card;
				}
			}
			// we can use regex here but since we will build ui there is no need
			System.out.println("Sorry that card is not in your had.");
			System.out.println("What would you like to play enter 1-13");
			System.out.println(name+"Hand:");
			for(Card card:hand){
				card.print();
			}
			num=in.nextInt();

		}
		//if null is returned error handling should catch it
		return null;
	}
	public boolean isLucky(Card card){
		if(card==null){
			return false;
		}
		if(card.getCardValue()==lucky){
			return true;
		}
		return false;
	}
	public String getName(){
		return name;
	}
	public void setDrinks(int drinks){
		this.drinks+=drinks;
	}
}
